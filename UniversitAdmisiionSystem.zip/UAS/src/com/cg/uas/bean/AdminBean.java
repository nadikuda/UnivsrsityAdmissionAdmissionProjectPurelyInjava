package com.cg.uas.bean;

public class AdminBean {

	private String adminusername;

	public String getAdminusername() {
		return adminusername;
	}

	public void setAdminusername(String adminusername) {
		this.adminusername = adminusername;
	}

	public String getAdminpassword() {
		return adminpassword;
	}

	public void setAdminpassword(String adminpassword) {
		this.adminpassword = adminpassword;
	}

	private String adminpassword;

	public AdminBean(String adminusername, String adminpassword) {
		super();
		this.adminusername = adminusername;
		this.adminpassword = adminpassword;
	}

	public AdminBean() {

	}
}
