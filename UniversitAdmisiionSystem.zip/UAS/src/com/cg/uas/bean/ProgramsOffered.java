package com.cg.uas.bean;

public class ProgramsOffered {

	String programName;
	String programDescription;
	String applicationEligibility;
	int duration;
	String degreeCertificationOffered;
	
// public int getProgramid() {
//		return programid;
//	}

//	public void setProgramid(int programid) {
//		this.programid = programid;
//	}

//private int programid;
	public ProgramsOffered() {
	}

	public ProgramsOffered(String programName, String programDescription,
			String applicationEligibility, int duration,
			String degreeCertificationOffered) {
		super();
		this.programName = programName;
		this.programDescription = programDescription;
		this.applicationEligibility = applicationEligibility;
		this.duration = duration;
		this.degreeCertificationOffered = degreeCertificationOffered;
		//this.programid=programid;
	}

	public String getProgramName() {
		return programName;
	}

	public void setProgramName(String programName) {
		this.programName = programName;
	}

	public String getProgramDescription() {
		return programDescription;
	}

	public void setProgramDescription(String programDescription) {
		this.programDescription = programDescription;
	}

	public String getApplicationEligibility() {
		return applicationEligibility;
	}

	public void setApplicationEligibility(String applicationEligibility) {
		this.applicationEligibility = applicationEligibility;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public String getDegreeCertificationOffered() {
		return degreeCertificationOffered;
	}

	public void setDegreeCertificationOffered(String degreeCertificationOffered) {
		this.degreeCertificationOffered = degreeCertificationOffered;
	}

}
