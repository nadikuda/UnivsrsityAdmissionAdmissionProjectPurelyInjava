package com.cg.uas.dao;

import java.util.ArrayList;

import com.cg.uas.bean.ApplicantBean;
import com.cg.uas.bean.ProgramsOffered;

public interface IApplicantDao {
	 int addApplicantDetails(ApplicantBean applicant);

	void displayall();
	public void displayprogramsschedule();
	String applicationstatus(int applicationid);
	String StatusAfterinterview(int applicationid);
	

	
}
