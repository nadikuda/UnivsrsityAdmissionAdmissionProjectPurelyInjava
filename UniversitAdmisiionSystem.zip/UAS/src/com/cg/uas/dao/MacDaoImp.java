package com.cg.uas.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

//import org.omg.CORBA.portable.ApplicationException;

import com.cg.uas.bean.ApplicantBean;
import com.cg.uas.dbutil.DBUtil;

public class MacDaoImp implements IMacDao {
	static Connection conn = null;

	public boolean maclogin(String macusername, String macpassword) {
		try {
			conn = DBUtil.getConnection();
			PreparedStatement preparedStatement = conn
					.prepareStatement(IQueryMapper.RETRIEVE_QUERY_MAC);

			preparedStatement.setString(1, macusername);

			preparedStatement.setString(2, macpassword);

			ResultSet rSet = preparedStatement.executeQuery();
			boolean data = rSet.next();
			return data;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;

	}

	@Override
	public ArrayList<ApplicantBean> scheduledprograms(int program) {
		ArrayList<ApplicantBean> specificprogram = new ArrayList<>();
		try {

			conn = DBUtil.getConnection();
			PreparedStatement preparestatement = conn
					.prepareStatement(IQueryMapper.RETRIEVE__SPECIFIC_PROGRAMS);

			// setting the interview date and accept
			PreparedStatement preparestatementforstatusandinterview = conn
					.prepareStatement(IQueryMapper.UPDATE_STATUS_COLUMN1);

			PreparedStatement preparestatementforstatusandinterview1 = conn
					.prepareStatement(IQueryMapper.UPDATE_STATUS_COLUMN2);

			PreparedStatement preparestatementforsearchingapplicationnumber = conn
					.prepareStatement(IQueryMapper.CHECKING_SCHEDULED_PROGRAM_AVAILABILITY_STRING);
			preparestatementforsearchingapplicationnumber.setInt(1, program);
      //checking the availability of application id
			int status = preparestatementforsearchingapplicationnumber
					.executeUpdate();
			if (status != 0) {

				preparestatement.setInt(1, program);
				ResultSet set = preparestatement.executeQuery();
				while (set.next()) {
					ApplicantBean applicantbean = new ApplicantBean();
					applicantbean.setApplicationid(set.getInt(1));
					applicantbean.setUsername(set.getString(2));
					applicantbean.setDob(set.getLong(3));

					// applicantbean.setProgramid(set.getInt(4));

					applicantbean.setQualification(set.getString(4));
					applicantbean.setMarks(set.getInt(5));
					applicantbean.setGoals(set.getString(6));
					applicantbean.setEmailid(set.getString(7));
					applicantbean.setScheduledprogramid(set.getInt(8));
					applicantbean.setDate_of_interview(set.getDate(9));

					applicantbean.setStatus(set.getString(10));
					specificprogram.add(applicantbean);

				}
			} else {
				System.err
						.println("==============================================");
				System.err
						.println("NO DATA FOUND WITH THIS ID TRY WITH OTHER ID: ");
				System.err
						.println("==============================================");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return specificprogram;
	}

	@Override
	public String macstatusupdate(int applicationid, String statusafterinterview) {
		String status1 = "";
		try {

			conn = DBUtil.getConnection();
			//here we will check the mac entered applicationid in table 
		
			PreparedStatement pstmtforcheckingavailabilityodapplicationid=conn.prepareStatement(IQueryMapper.CHECKING_AVAILABILITY_OF_APPLICATION_ID);
			pstmtforcheckingavailabilityodapplicationid.setInt(1, applicationid);
			
			int status4=pstmtforcheckingavailabilityodapplicationid.executeUpdate();
			
			if(status4 !=0){
				
			PreparedStatement preparestatement = conn
					.prepareStatement(IQueryMapper.STATUS_UPDATE_AFTER_INTERVIEW_STRING);
			preparestatement.setString(1, statusafterinterview);
			preparestatement.setInt(2, applicationid);
			int status = preparestatement.executeUpdate();
			if (status == 1) {
				status1 = "UPDATED SUCCESSFULLY";
			} else {
				status1 = "NOT UPADTED";
			}
		}else{
			System.err.println("=========================================");
			System.err.println("ENTERED APPLICATION ID IS NOT AVAIALABLE:");
			System.err.println("=========================================");
		}
		}catch (Exception e) {
			System.out.println(e);
		}

		return status1;
	}
}
