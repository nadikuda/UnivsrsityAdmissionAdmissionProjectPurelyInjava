package com.cg.uas.dao;

public interface IQueryMapper {
	//interface will consist of all queries that manipulates data
	public static final String INSERT_QUERY = "insert into application values(applicantid_seq.NEXTVAL,?,?,?,?,?,?,?,NULL,'NULL')";
	public static final String IDVALUE = "SELECT applicantid_seq.currval FROM DUAL";

	public static final String programs = "select * from programs";

	public static final String RETRIEVE_QUERY_ADMIN = "select adminusername,adminpassword from admintable where adminusername=? and adminpassword=?";
	public static final String RETRIEVE_QUERY_MAC = "select macusername,macpassword from mactable where macusername=? and macpassword=?";
	public static final String RETRIEVE__SPECIFIC_PROGRAMS = "select * from application where scheduled_program_id=?";

	public static final String RETRIEVE_ALL_PROGRAMS = "select * from programs_table";

	public static final String INSERT_INTO_PROGRAMS_TABLE = "insert into programs_table values(?,?,?,to_date(?, 'dd-MM-yyyy'),to_date(?, 'dd-MM-yyyy'),?)";
	public static final String IDFORINSERTINGPROGRAMNEWSCHEDULED = "SELECT programinsertionid_seq.NEXTVAL FROM DUAL";

	// inserting into data to programs offered by university

	public static final String INSERT_INTO_PROGRAMS_STRING = "insert into programs values(?,?,?,?,?)";
	//searching application based on application id
	public static final String CHECKING_SCHEDULED_PROGRAM_AVAILABILITY_STRING="select application_id from application where scheduled_program_id=?";
	public static final String DELETE_PROGRAM = "delete from programs where program=?";
	public static final String IDVALUE_FOR_INSERTINGNEWPROGRAM = "SELECT newprograminsertionid_seq.NEXTVAL from dual";

	public static final String RETRIEVE_STATUS_DATE_OF_INTERVIEW = "select status,date_of_interview from application where application_id=?";

	public static final String UPDATE_STATUS_COLUMN1 = "update  application set status='Accepted',date_of_interview=sysdate+10 where marks_obtained > ? ";
	public static final String UPDATE_STATUS_COLUMN2 = "update application set status='Rejected',date_of_interview=null where marks_obtained < ? ";

	public static final String SELECT_STATUS_AFTER_INTERVIEW = "select status from application where application_id=?";
	public static final String STATUS_UPDATE_AFTER_INTERVIEW_STRING = "update application set status=? where application_id=?";
	// RETIEVE_QUERY_ADMIN="select * from admintable";
	public static final String DELETE_SCHEDULED_PROGRAM="delete from programs_table where scheduled_program_id=?";
	//this query will give you the list accepted or rejected people list
	public static final String LIST_OF_ACCEPTED_OR_REJECTED="select application_id from application where status=?";
	public static final String VIEW_ALL_APPLICATIONS_BY_ADMIN="select application_id,full_name,date_of_birth,highest_qualification,marks_obtained,goals,email_id,scheduled_program_id,status from application";
	// query for checking the availability of applixation id;
	public static final String CHECKING_AVAILABILITY_OF_APPLICATION_ID ="select application_id from application where application_id=?";
	public static final String SELECTING_ALL_PROGRAM_NAMES="select program from programs where program=?";
//id value for  inserting data
	//public static final String ID_FOR_INSERTING_NEW_SCHEDULED_PROGRAM="select newscheduledprogrmaid_seq.NEXTVAL from dual";
	public static final String LIST_OF_PROGRAMS="select program from programs ";
}
