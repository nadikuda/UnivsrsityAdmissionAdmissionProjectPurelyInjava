package com.cg.uas.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.cg.uas.bean.AdminBean;
import com.cg.uas.dao.AdminDaoImp;
import com.cg.uas.exception.UserException;

public class Logintest {
	AdminBean adminbean=new AdminBean();
	AdminDaoImp admin=new AdminDaoImp();

	@Test
	public void test() throws UserException {
		
		assertEquals(true, admin.adminlogin("admin","password"));
	}

}
