package com.cg.uas.services;

import java.util.ArrayList;

import com.cg.uas.bean.AdminBean;
import com.cg.uas.bean.ApplicantBean;
import com.cg.uas.bean.ProgramsOffered;


public interface IApplicantService {
 int addApplicantDetails(ApplicantBean applicant);
 public void displayall();
 public void displayprogramsschedule();
String applicationstatus(int applicationid);
String StatusAfterinterview(int applicationid);
 
 }

	
	
	


