package com.cg.uas.services;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.uas.bean.ApplicantBean;
import com.cg.uas.bean.ProgramsOffered;
import com.cg.uas.dao.ApplicantDaoImp;
import com.cg.uas.dao.IApplicantDao;

public class ApplicantService implements IApplicantService {

	IApplicantDao dao = null;

	@Override
	public int addApplicantDetails(ApplicantBean applicant) {

		dao = new ApplicantDaoImp();
		return dao.addApplicantDetails(applicant);
	}

	@Override
	public void displayall() {
		dao = new ApplicantDaoImp();
		dao.displayall();

	}

	@Override
	public void displayprogramsschedule() {
		dao = new ApplicantDaoImp();
		dao.displayprogramsschedule();

	}

	@Override
	public String applicationstatus(int applicationid) {
		dao = new ApplicantDaoImp();
		return dao.applicationstatus(applicationid);
	}

	@Override
	public String StatusAfterinterview(int applicationid) {
		dao = new ApplicantDaoImp();
		return dao.StatusAfterinterview(applicationid);
	}

	public boolean isValidApplicantname(String applicantname) {

		Pattern namePattern = Pattern.compile("[A-Za-z ]{8,}$");
		Matcher nameMatcher = namePattern.matcher(applicantname);

		return nameMatcher.matches();
	}

	public boolean isValidApplicantDob(long dob) {

		String string = Long.toString(dob);// converting dob into string
		Pattern dobPattern = Pattern.compile("[0-9]{8}");
		Matcher dobMatcher = dobPattern.matcher(string);
		return dobMatcher.matches();
	}

	public boolean isValidApplicantQualification(String qualification) {
		Pattern qualificationPattern = Pattern.compile("[a-zA-z0-9 ]*");
		Matcher qualificationMatcher = qualificationPattern
				.matcher(qualification);
		return qualificationMatcher.matches();
	}

	public boolean isValidApplicantGoals(String goals) {
		Pattern goalsPattern = Pattern.compile("[a-zA-z ]*");
		Matcher goalsMatcher = goalsPattern
				.matcher(goals);
		return goalsMatcher.matches();
		
	}

	public boolean isValidEmail(String applicantemail) {
		Pattern emailPattern=Pattern.compile("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+.[A-Za-z]{2,}$");
		Matcher emailMatcher=emailPattern.matcher(applicantemail);
		return emailMatcher.matches();
	}

	public boolean isvalidScheduledProgramId(int programid) {
		String string=Integer.toString(programid);
		Pattern scheduledProgramIdPattern=Pattern.compile("[0-9]{3}");
		Matcher scheduledprogramMatcher=scheduledProgramIdPattern.matcher(string);
		return scheduledprogramMatcher.matches();
	}

	public boolean isValidApplicationIdForStatusAfterApplication(int applicantid) {
		String string=Integer.toString(applicantid);
		Pattern scheduledProgramIdPattern=Pattern.compile("[0-9]{4}");
		Matcher scheduledprogramMatcher=scheduledProgramIdPattern.matcher(string);
		return scheduledprogramMatcher.matches();
		
	}

}
